% Jaccardϵ��
% function dist1 = dist_Jaccard(x,y)
function dist1 = dm(x,y)
[m,n]=size(x);
f01 = 0;
f10 = 0;
f11 = 0;
for i=1:n
    if(x(i)==0 && y(i)==1)
        f01 = f01+1;
    elseif(x(i)==1 && y(i)==0)
        f10 = f10+1;
    elseif(x(i)==1 && y(i)==1)
        f11 = f11+1;
    end
end
B=f01+f10+f11;
if B==0
    dist1 =0;
else
    dist1 = f11/(f01+f10+f11);
end
end