function [P] = GetProbability(M)
%%sigmoid����
    P = exp(M) ./ (1 + exp(M));
end
