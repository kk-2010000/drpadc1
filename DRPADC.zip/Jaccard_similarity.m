function [DG,dG]=Jaccard_similarity(A)
[m,n]=size(A);
DG=zeros(m);
dG=zeros(n);

for i=1:m
    for j=i:m
        
        DG(i,j)=dm(A(i,:),A(j,:));
        DG(j,i)=DG(i,j);
    end
end   
C=A';
for i=1:n
    for j=i:n
        
        dG(i,j)=dm(C(i,:),C(j,:));
        dG(i,j)=dG(j,i);
    end
end 
end