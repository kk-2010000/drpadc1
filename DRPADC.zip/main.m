clc;clear;
warning('off');
tic


%%
% %Fdataset
% dSS= textread('./drug_Data/DiseaseSim.txt');
% A = xlsread('./drug_Data/DiDrA.xls');
% A=A';
% DCS=textread('./drug_Data/DrugSim.txt');%DrugSim,593*313

 %%
% % Cdataset
dSS= textread('./drug_Data/Cdataset/DiseaseSim.txt');
A = xlsread('./drug_Data/Cdataset/DiDrA.xls');
A=A';
DCS=textread('./drug_Data/Cdataset/DrugSim.txt');%DrugSim,663*663


%%
A_ori=A;
    y_train=WKNKN( A, DCS, dSS, 1*7, 0.1*6); 
% 
  [DG,dG]=Jaccard_similarity(y_train);%�ܿ��������ԣ�����������
  y=A_ori;

  gamma_net = 2^0;
   [K_COM1,K_COM2] = CT(y,y_train,DCS,DG,dSS,dG,gamma_net);

    F_1_ori=CompressSensingExample(y_train,K_COM1,K_COM2);





F_1_ori_ori=F_1_ori;
index=find(A_ori==1);
auc = zeros(1,10);
aupr=zeros(1,10);
pre=zeros(1,10);
for i = 1:10
    i
    indices = crossvalind('Kfold', length(index), 10);
    A = A_ori;
    F_1_ori=F_1_ori_ori;  
    for cv = 1:10
        cv;
        index_2 = find(cv == indices);      
        A(index(index_2)) = 0; 
%        
             y_train_1=WKNKN( A, DCS, dSS, 1*7, 0.1*6); 
%         
          y1=y;
          y1(index(index_2)) = 0;     
         [DG1,dG1]=Jaccard_similarity(y_train_1);
          [K_COM11,K_COM21] = CT(y1,y_train_1,DCS,DG1,dSS,dG1,gamma_net);

            F_1=CompressSensingExample(y_train_1,K_COM11,K_COM21); 

        F_1_ori(index(index_2)) = F_1(index(index_2));
        
        A = A_ori;
    end


    pre_label_score = F_1_ori(:);
    label_y = A_ori(:);
    auc(i) = roc_1(pre_label_score,label_y,'red');
    aupr(i) =pr_cure(pre_label_score,label_y,'blue');

    auc(i)
end
auc_ave = mean(auc);
auc_std = std(auc);
aupr_ave = mean(aupr);
aupr_std = std(aupr);


toc